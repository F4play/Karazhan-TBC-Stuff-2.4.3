# DiamondThreatMeter

A reskin of DTM for World of Warcraft 2.4.3 by Lulleh

![Meter example](https://i.imgur.com/Hx3rSCO.jpg)
