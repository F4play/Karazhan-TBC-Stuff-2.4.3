--------------------------------------------------------------------------
-- GTFO.lua 
--------------------------------------------------------------------------
--[[
GTFO
Author: Lyta of Malygos

Usage: /GTFO and check Interface->Add-ons

Note: Place your own custom spells and setups in GTFO_Custom.lua

Change Log:
	v0.1
		- Beta Release
		- Added menu options
	v0.2
		- Put spells in its own area
	v0.3
		- Updated for Wrath spells
	v0.3.1
		- Updated for Naxx spells
	v0.3.2
		- More spells
	v0.3.3
		- More spells
	v1.0
		- Public Release
		- More spells
		- High/Low options
	v1.0.1
		- Added spells, replaced names with spell IDs
	v1.1
		- Bug fixes
		- Added "test" buttons to the menu option
		- Added spells, replaced names with spell IDs
		- Sound spam prevention
		- Alerts on "afflicted by" event
	v1.1.1
		- Spell fixes, new spells, replaced names with spell IDs
		- Added the ability to alert only on DoT application
		- Fixed "afflicted by" alerts to support stacking debuffs
	v1.1.2
		- Added spells
	v1.1.3
		- Added spells
	v1.1.4
		- Added spells
]]--

GTFO = {
	Version = "1.1.4";
	VersionNumber = 10104;
	DataCode = "1";
	DebugMode = nil;
	SpellName = { };
	SpellID = { };
	UpdateFound = nil;
	IgnoreTimeAmount = .2;
	IgnoreTime = nil;
}

GTFOData = {};

function GTFO_ChatPrint(str)
	DEFAULT_CHAT_FRAME:AddMessage("[GTFO] "..str, 0.25, 1.0, 0.25);
end

function GTFO_ErrorPrint(str)
	DEFAULT_CHAT_FRAME:AddMessage("[GTFO] "..str, 1.0, 0.5, 0.5);
end

function GTFO_DebugPrint(str)
	if (GTFO.DebugMode) then
		DEFAULT_CHAT_FRAME:AddMessage("[GTFO] "..str, 0.75, 1.0, 0.25);
	end
end

function GTFO_OnEvent(event)
	if (event == "VARIABLES_LOADED") then
		if (GTFOData.DataCode ~= GTFO.DataCode) then
			GTFOData.Active = true;
			GTFOData.Sounds = { };
			GTFOData.Sounds[1] = true;
			GTFOData.Sounds[2] = true;
			GTFOData.DataCode = GTFO.DataCode;
			GTFO_ChatPrint("v"..GTFO.Version..": New database version detected, resetting defaults.");
		end
		GTFO_RenderOptions();
		GTFO_Option_Active(GTFOData.Active);
		GTFO_Option_HighSound(GTFOData.Sounds[1]);
		GTFO_Option_LowSound(GTFOData.Sounds[2]);
		if (GTFOData.Active) then
			GTFO_ChatPrint("v"..GTFO.Version.." loaded.");
		else
			GTFO_ChatPrint("v"..GTFO.Version.." loaded. (|cFFFF1111Suspended|r)");
		end
	end
	if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		local SpellType = arg2.."";
		
		if (SpellType=="ENVIRONMENTAL_DAMAGE" and arg6==UnitGUID("player")) then
			GTFO_DebugPrint(SpellType.." - "..arg9);
			if (arg9 ~= "FALLING") then
				GTFO_PlaySound(2);
			end
		end
		if ((SpellType=="SPELL_PERIODIC_DAMAGE" or SpellType=="SPELL_DAMAGE" or ((SpellType=="SPELL_AURA_APPLIED" or SpellType=="SPELL_AURA_APPLIED_DOSE") and arg12=="DEBUFF")) and arg6==UnitGUID("player")) then
			local SpellID = arg9.."";
			local SpellName = arg10.."";
			GTFO_DebugPrint(SpellType.." - "..SpellID.." - "..SpellName);
			if (GTFO.SpellID[SpellID]) then
				GTFO_DebugPrint(SpellID.." - ID Match Found");
				if ((not GTFO.SpellID[SpellID].applicationOnly) or (GTFO.SpellID[SpellID].applicationOnly and (SpellType == "SPELL_AURA_APPLIED" or SpellType == "SPELL_AURA_APPLIED_DOSE"))) then
					GTFO_PlaySound(GTFO.SpellID[SpellID].sound);
					GTFO_DebugPrint(GTFO.SpellID[SpellID].desc);
				end
			elseif (GTFO.SpellName[SpellName]) then
				GTFO_DebugPrint(SpellName.." - Name Match Found");
				if ((not GTFO.SpellName[SpellName].applicationOnly) or (GTFO.SpellName[SpellName].applicationOnly and (SpellType == "SPELL_AURA_APPLIED" or SpellType == "SPELL_AURA_APPLIED_DOSE"))) then
					GTFO_PlaySound(GTFO.SpellName[SpellName].sound);
					GTFO_DebugPrint(GTFO.SpellName[SpellName].desc);				
				end
			end
		end
	end
end

function GTFO_Command(arg1)
	local Command = string.upper(arg1);
	local DescriptionOffset = string.find(arg1,"%s",1);
	local Description = nil;
	
	if (DescriptionOffset) then
		Command = string.upper(string.sub(arg1, 1, DescriptionOffset - 1));
		Description = string.sub(arg1, DescriptionOffset + 1).."";
	end
	
	GTFO_DebugPrint("Command executed: "..Command);
	
	if (Command == "STANDBY") then
		GTFO_Command_Standby();
	elseif (Command == "DEBUG") then
		GTFO_Command_Debug();
	elseif (Command == "TEST") then
		GTFO_PlaySound(1);
		GTFO_ChatPrint("Test sound playing.");
	elseif (Command == "HELP" or Command == "") then
		GTFO_Command_Help();
	else
		GTFO_Command_Help();
	end
end

function GTFO_Command_Debug()
	if (GTFO.DebugMode) then
		GTFO.DebugMode = nil;
		GTFO_ChatPrint("Debug mode off.");
	else
		GTFO.DebugMode = true;
		GTFO_ChatPrint("Debug mode on.");
	end
end

function GTFO_Command_Standby()
	if (GTFOData.Active) then
		GTFO_Option_Active(nil);
		GTFO_ChatPrint("Addon suspended.");
	else
		GTFO_Option_Active(true);
		GTFO_ChatPrint("Addon resumed.");
	end
	GTFO_ActivateMod();
end

function GTFO_OnLoad()
    this:RegisterEvent("VARIABLES_LOADED");
	SlashCmdList["GTFO"] = GTFO_Command;
    SLASH_GTFO1 = "/GTFO";
end

function GTFO_PlaySound(iSound)
	local currentTime = GetTime();
	if (GTFO.IgnoreTime) then
		if (currentTime < GTFO.IgnoreTime) then
			return;
		end
	end
	GTFO.IgnoreTime = currentTime + GTFO.IgnoreTimeAmount;
	local soundTable = {
		"Interface\\AddOns\\GTFO\\Sounds\\alarmbuzzer.wav",
		"Interface\\AddOns\\GTFO\\Sounds\\alarmbeep.wav",
	};
	if (GTFOData.Sounds[iSound]) then
		PlaySoundFile(soundTable[iSound]);
	end
end

function GTFO_RenderOptions()
	local ConfigurationPanel = CreateFrame("FRAME","GTFO_MainFrame");
	ConfigurationPanel.name = "GTFO";
	InterfaceOptions_AddCategory(ConfigurationPanel);

	local EnabledButton = CreateFrame("CheckButton", "GTFO_EnabledButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	EnabledButton:SetPoint("TOPLEFT", 10, -15)
	EnabledButton.tooltip = "Enable the GTFO mod."
	getglobal(EnabledButton:GetName().."Text"):SetText("Enabled");

	local HighSoundButton = CreateFrame("CheckButton", "GTFO_HighSoundButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	HighSoundButton:SetPoint("TOPLEFT", 10, -45)
	HighSoundButton.tooltip = "Enable GTFO buzzer sounds"
	getglobal(HighSoundButton:GetName().."Text"):SetText("Raid/High Damage sounds");

	local LowSoundButton = CreateFrame("CheckButton", "GTFO_LowSoundButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	LowSoundButton:SetPoint("TOPLEFT", 10, -75)
	LowSoundButton.tooltip = "Enable GTFO boop sounds"
	getglobal(LowSoundButton:GetName().."Text"):SetText("PvP/Environment/Low Damage sounds");

	local HighTestButton = CreateFrame("Button", "SmartError_HighTestButton", ConfigurationPanel, "OptionsButtonTemplate");
	HighTestButton:SetPoint("TOPLEFT", 300, -45);
	HighTestButton.tooltip = "Test the sound.";
	HighTestButton:SetScript("OnClick",GTFO_Option_HighTest);
	getglobal(HighTestButton:GetName().."Text"):SetText("Test");

	local LowTestButton = CreateFrame("Button", "SmartError_LowTestButton", ConfigurationPanel, "OptionsButtonTemplate");
	LowTestButton:SetPoint("TOPLEFT", 300, -75);
	LowTestButton.tooltip = "Test the sound.";
	LowTestButton:SetScript("OnClick",GTFO_Option_LowTest);
	getglobal(LowTestButton:GetName().."Text"):SetText("Test");

	ConfigurationPanel.okay = 
		function (self)
			GTFO_Option_Active(EnabledButton:GetChecked());
			GTFO_Option_HighSound(HighSoundButton:GetChecked());
			GTFO_Option_LowSound(LowSoundButton:GetChecked());
		end
	ConfigurationPanel.cancel = 
		function (self)
			EnabledButton:SetChecked(GTFOData.Active);
			HighSoundButton:SetChecked(GTFOData.Sounds[1]);
			LowSoundButton:SetChecked(GTFOData.Sounds[2]);
		end
	ConfigurationPanel.default = 
		function (self)
			GTFO_Option_Active(true);
			GTFO_Option_HighSound(true);
			GTFO_Option_LowSound(true);
		end
end

function GTFO_ActivateMod()
	if (GTFOData.Active) then
		GTFOFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	else
		GTFOFrame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	end	
end

function GTFO_Option_Active(state)
	GTFOData.Active = state;
	getglobal("GTFO_EnabledButton"):SetChecked(state);
	GTFO_ActivateMod();
end

function GTFO_Command_Help()
	DEFAULT_CHAT_FRAME:AddMessage("[GTFO] v"..GTFO.Version.." (|cFFFFFFFFCommand List|r)", 0.25, 1.0, 0.25);
	if not (GTFOData.Active) then
		DEFAULT_CHAT_FRAME:AddMessage("The addon is currently suspended.", 1.0, 0.1, 0.1);		
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/gtfo standby|r -- Suspend/Resume addon", 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/gtfo test|r -- Play a test sound", 0.25, 1.0, 0.75);
end

function GTFO_Option_HighSound(state)
	GTFOData.Sounds[1] = state;
	getglobal("GTFO_HighSoundButton"):SetChecked(state);
end

function GTFO_Option_LowSound(state)
	GTFOData.Sounds[2] = state;
	getglobal("GTFO_LowSoundButton"):SetChecked(state);
end

function GTFO_Option_HighTest()
	GTFO_PlaySound(1);
end

function GTFO_Option_LowTest()
	GTFO_PlaySound(2);
end
